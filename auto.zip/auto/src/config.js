export const DEFAULT_BROWSERS = ["last 4 version"];
export const CSS_EXAMPLE = `.example {
    display: grid;
    transition: all .5s;
    user-select: none;
    background: linear-gradient(to bottom, white, black);
}
`
